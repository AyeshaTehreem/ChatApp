import React from 'react';
import ChatSidebar from '../components/ChatSidebar';
import ChatWindow from '../components/ChatWindow';
import ProfileSidebar from '../components/ProfileSidebar';

function ChatPage() {
    return (
        <div className="flex h-screen">
            <ProfileSidebar/>
            <ChatSidebar />
            <ChatWindow />
        </div>
    );
}

export default ChatPage;
