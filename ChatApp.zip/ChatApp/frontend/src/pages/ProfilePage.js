import React from 'react';

function ProfilePage() {
    return (
        <div className="flex justify-center items-center h-screen bg-gray-100">
            <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
                <h2 className="text-2xl mb-4">User Profile</h2>
                {/* User profile details */}
                <div className="mb-4">
                    <label className="block text-gray-700">Username</label>
                    <input type="text" className="w-full border border-gray-300 p-2 rounded-lg" disabled value="John Doe" />
                </div>
                <div className="mb-4">
                    <label className="block text-gray-700">Email</label>
                    <input type="email" className="w-full border border-gray-300 p-2 rounded-lg" disabled value="john@example.com" />
                </div>
                <button className="w-full bg-blue-500 text-white p-2 rounded-lg">Update Profile</button>
            </div>
        </div>
    );
}

export default ProfilePage;
