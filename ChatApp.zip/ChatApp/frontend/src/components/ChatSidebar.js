// ChatSidebar.js
import React from 'react';
import { FaSearch, FaEllipsisV } from 'react-icons/fa';

function ChatSidebar() {
    return (
        <div className="w-2/5 bg-white text-gray-900 p-4">
            <div className="flex items-center justify-between mb-6">
                <h1 className="text-3xl font-bold">Chats</h1>
                <div className="flex items-center space-x-2">
                    {/* Circular colorful AI icon */}
                    <div className="w-10 h-10 flex items-center justify-center rounded-full bg-gradient-to-r from-green-400 to-blue-500 text-white text-2xl">
                        AI
                    </div>
                    <button className="text-black hover:text-gray-700 text-xl">
                        <FaEllipsisV />
                    </button>
                </div>
            </div>
            <div className="mb-4 relative">
                <input
                    type="text"
                    placeholder="Search"
                    className="w-full border border-gray-300 text-gray-700 p-2 pl-10 rounded-lg bg-gray-200 text-lg"
                />
                <FaSearch className="absolute top-1/2 left-3 transform -translate-y-1/2 text-gray-700" />
            </div>
            <div className="mb-6 flex gap-2">
                <button className="bg-gray-200 text-gray-700 py-2 px-4 rounded-full text-xl inline-flex items-center hover:bg-green-100 transition-colors duration-200">
                    All
                </button>
                <button className="bg-gray-200 text-gray-700 py-2 px-6 rounded-full text-xl inline-flex items-center hover:bg-green-100 transition-colors duration-200">
                    Unread
                </button>
                <button className="bg-gray-200 text-gray-700 py-2 px-6 rounded-full text-xl inline-flex items-center hover:bg-green-100 transition-colors duration-200">
                    Groups
                </button>
            </div>
            <ul className="space-y-2">
                {/* Replace with dynamic list of conversations */}
                <ConversationItem
                    profilePic="https://via.placeholder.com/150"
                    name="John Doe"
                    time="10:45 AM"
                    lastMessage="Hey, how’s it going?"
                />
                <ConversationItem
                    profilePic="https://via.placeholder.com/150"
                    name="Jane Smith"
                    time="9:15 AM"
                    lastMessage="Don’t forget the meeting later!"
                />
                <ConversationItem
                    profilePic="https://via.placeholder.com/150"
                    name="Alice Johnson"
                    time="8:30 AM"
                    lastMessage="Looking forward to our call."
                />
                <ConversationItem
                    profilePic="https://via.placeholder.com/150"
                    name="Bob Brown"
                    time="Yesterday"
                    lastMessage="Can we reschedule our meeting?"
                />
                <ConversationItem
                    profilePic="https://via.placeholder.com/150"
                    name="Emily Davis"
                    time="Last week"
                    lastMessage="Just checking in on the project."
                />
                <ConversationItem
                    profilePic="https://via.placeholder.com/150"
                    name="Michael Wilson"
                    time="2 days ago"
                    lastMessage="Thanks for the update!"
                />
                {/* Add more ConversationItem components as needed */}
            </ul>
        </div>
    );
}

function ConversationItem({ profilePic, name, time, lastMessage }) {
    return (
        <li className="flex items-center p-3 hover:bg-gray-100 cursor-pointer rounded-lg">
            {/* Profile Picture */}
            <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                <img src={profilePic} alt={name} className="w-full h-full object-cover" />
            </div>

            {/* Conversation Details */}
            <div className="flex-1">
                <div className="flex justify-between items-center mb-1">
                    <span className="font-semibold text-gray-800">{name}</span>
                    <span className="text-gray-500 text-sm">{time}</span>
                </div>
                <div className="text-gray-600 text-sm truncate">{lastMessage}</div>
            </div>
        </li>
    );
}

export default ChatSidebar;
