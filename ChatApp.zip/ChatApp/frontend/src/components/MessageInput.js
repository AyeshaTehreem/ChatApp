// MessageInput.js
import React, { useState } from 'react';
import { useWebSocket } from './websocket-context';

const MessageInput = () => {
    const { ws } = useWebSocket();
    const [message, setMessage] = useState('');

    const sendMessage = () => {
        if (message.trim() !== '' && ws) {
            const messageObj = {
                sender: 'You',
                text: message
            };
            ws.send(JSON.stringify(messageObj));
            setMessage('');
        }
    };

    return (
        <div className="message-input">
            <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                        sendMessage();
                    }
                }}
            />
            <button onClick={sendMessage}>Send</button>
        </div>
    );
};

export default MessageInput;
