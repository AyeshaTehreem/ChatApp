// src/components/ChatWindow.js
import React from 'react';
import { useWebSocket } from '../websocket-context'; // Import with correct path

function ChatWindow() {
    const { ws, messages } = useWebSocket();

    const sendMessage = (message) => {
        if (ws) {
            ws.send(JSON.stringify({ sender: 'You', text: message }));
        }
    };

    return (
        <div className="chat-window">
            {/* Example content */}
            <div>
                {messages.map((msg, index) => (
                    <div key={index}>{msg.text}</div>
                ))}
            </div>
            {/* Add message input and other UI components */}
        </div>
    );
}

export default ChatWindow;
