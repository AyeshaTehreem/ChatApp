import React, { useState } from 'react';
import { FaUserCircle, FaUsers, FaRegCommentDots } from 'react-icons/fa';
import { MdMessage } from 'react-icons/md';

function ProfileSidebar() {
    const [activeIndex, setActiveIndex] = useState(null);

    const handleClick = (index) => {
        setActiveIndex(index);
    };

    return (
        <div className="w-20 bg-gray-200 text-gray-900 p-4 flex flex-col h-screen">
            <div className="flex flex-col justify-between flex-grow">
                <div className="flex flex-col space-y-12">
                    {/* 1. Chat Icon */}
                    <button
                        className={`text-gray-700 hover:bg-gray-300 hover:text-gray-900 text-4xl p-2 rounded-full transition-colors ${
                            activeIndex === 0 ? 'bg-gray-300 text-gray-900' : ''
                        }`}
                        onClick={() => handleClick(0)}
                    >
                        <MdMessage />
                    </button>
                    {/* 2. Status Icon */}
                    <button
                        className={`text-gray-700 hover:bg-gray-300 hover:text-gray-900 text-4xl p-2 rounded-full transition-colors ${
                            activeIndex === 1 ? 'bg-gray-300 text-gray-900' : ''
                        }`}
                        onClick={() => handleClick(1)}
                    >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="w-8 h-8"
                        >
                            {/* Outer dotted circle */}
                            <circle cx="12" cy="12" r="10" stroke="black" strokeWidth="2" fill="none" strokeDasharray="8,4" />
                            {/* Inner hollow circle */}
                            <circle cx="12" cy="12" r="6" stroke="black" strokeWidth="2" fill="none" />
                        </svg>
                    </button>
                    {/* 3. Bubble Icon */}
                    <button
                        className={`text-gray-700 hover:bg-gray-300 hover:text-gray-900 text-4xl p-2 rounded-full transition-colors ${
                            activeIndex === 2 ? 'bg-gray-300 text-gray-900' : ''
                        }`}
                        onClick={() => handleClick(2)}
                    >
                        <FaRegCommentDots className="rotate-180-custom" />
                    </button>
                    {/* 4. Group Icon */}
                    <button
                        className={`text-gray-700 hover:bg-gray-300 hover:text-gray-900 text-4xl p-2 rounded-full transition-colors ${
                            activeIndex === 3 ? 'bg-gray-300 text-gray-900' : ''
                        }`}
                        onClick={() => handleClick(3)}
                    >
                        <FaUsers />
                    </button>
                </div>
                {/* 5. User Profile Icon */}
                <button
                    className={`text-gray-700 hover:bg-gray-300 hover:text-gray-900 text-4xl p-2 rounded-full transition-colors ${
                        activeIndex === 4 ? 'bg-gray-300 text-gray-900' : ''
                    } mb-4`}
                    onClick={() => handleClick(4)}
                >
                    <FaUserCircle />
                </button>
            </div>
        </div>
    );
}

export default ProfileSidebar;
