// server.js
const WebSocket = require('ws');
const express = require('express');
const http = require('http');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Store connected clients
let clients = [];

// Handle WebSocket connections
wss.on('connection', (ws) => {
    clients.push(ws);

    ws.on('message', (message) => {
        // Broadcast incoming message to all clients
        clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(message);
            }
        });
    });

    ws.on('close', () => {
        // Remove the client when disconnected
        clients = clients.filter(client => client !== ws);
    });
});

// Serve static files (if needed)
app.use(express.static('public'));

server.listen(3001, () => {
    console.log('Server listening on port 3001');
});
